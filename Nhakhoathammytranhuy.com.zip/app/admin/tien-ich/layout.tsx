import React from "react";

const PluginLayout = ({ children }: { children: React.ReactNode }) => {
  return <>{children}</>;
};

export default PluginLayout;
