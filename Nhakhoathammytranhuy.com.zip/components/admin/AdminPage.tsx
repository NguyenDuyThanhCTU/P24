import React from "react";

const AdminPage = () => {
  return <div>Encanomoya</div>;
};

export default AdminPage;
