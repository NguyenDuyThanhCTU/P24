import React from "react";

const PostIntroductory = () => {
  return <div>PostIntroductory</div>;
};

export default PostIntroductory;
