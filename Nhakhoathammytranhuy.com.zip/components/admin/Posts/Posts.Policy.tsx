import React from "react";

const PostPolicy = () => {
  return <div>PostPolicy</div>;
};

export default PostPolicy;
