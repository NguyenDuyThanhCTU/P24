import { initializeApp } from "firebase/app";
import { getFirestore, initializeFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
const firebaseConfig = {
  apiKey: "AIzaSyDB3swk0zWGrwThr9SHQapNnfQDg_yXVEM",

  authDomain: "nhakhoathammytranhuy.firebaseapp.com",

  projectId: "nhakhoathammytranhuy",

  storageBucket: "nhakhoathammytranhuy.appspot.com",

  messagingSenderId: "966791372762",

  appId: "1:966791372762:web:3e11a1c6cb732ac62e6ae3",

  measurementId: "G-ZPXJB32HMJ",
};

const app = initializeApp(firebaseConfig);
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
});

export const auth = getAuth(app);
